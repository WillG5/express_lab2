"use strict";

const express = require("express");
const app = express();
const port = 8888;
const shoppingcart = require("./routes");

app.use(express.static("./public"));
app.use(express.json());
app.use("/", shoppingcart);


app.listen(port, _ => console.log(`Server is up and running.`));