"use strict";

angular
  .module("App")
  .controller("HomeController", function(HomeService) {
    const $ctrl = this;

    function changes(response) {
      $ctrl.baskets = response.data;
    }

    $ctrl.updateData = (item) => {
      HomeService.updateData(item).then(changes);
    };

    HomeService.getData().then(changes);
    
    $ctrl.deleteData = (id) => {
      HomeService.deleteData(id).then(changes);
    };
    
    $ctrl.postData = (newCart) => {
      HomeService.postData(newCart).then(changes);
    };
  });