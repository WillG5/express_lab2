"use strict";

angular
  .module("App")
  .service("HomeService", function($http) { 
    const service = this;

    service.postData = (newCart) => {
      return $http({
        method: "POST",
        url: "/shoppingcart",
        data: newCart 
      });
    };

    service.updateData = (cart) => {
      return $http({
        method: "PUT",
        url: `/shoppingcart/${cart.id}`, 
        data: cart
      });
    };

    service.deleteData = (id) => {
      return $http({
        method: "DELETE",
        url: `/shoppingcart/${id}` 
      });
    };

    service.getData = () => {
      return $http({
        method: "GET",
        url: "/shoppingcart"
      });
    };
  });