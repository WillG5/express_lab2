"use strict";
const home = {
  
  templateUrl: "home/home.html",
  controller: "HomeController"
};

angular.module("App").component("home", home);