"use strict";
angular.module("App", []);