"use strict";

const express = require("express");
const shoppingcart = express.Router();
const pool = require("./db");

shoppingcart.get("/shoppingcart", (req, res) => {
  pool.query("select * from shoppingcart").then((result) => {
    res.json(result.rows);
  });
});

shoppingcart.post("/shoppingcart", (req, res) => {
  pool.query("insert into shoppingcart(product, price, quantity) values($1::text, price=$2::float, quantity=$3::int)", [req.body.product, req.body.price, req.body.quantity]).then(() => {
    pool.query("select * from shoppingcart").then((result) => {
      res.json(result.rows);
    });
  });
});

shoppingcart.put("/shoppingcart/:id", (req, res) => {
  pool.query("update shoppingcart set product=$1::text, price=$2::float, quantity=$3::int where id=$4::int", [req.body.product, req.body.price, req.body.quantity, req.params.id]).then(() => {
    pool.query("select * from shoppingcart").then((result) => {
      res.json(result.rows);
    });
  });
});

shoppingcart.delete("/shoppingcart/:id", (req, res) => {
  pool.query("delete from shoppingcart where id=$1::int", [req.params.id]).then(() => {
    pool.query("select * from shoppingcart").then((result) => {
      res.json(result.rows);
    });
  });
});

module.exports = shoppingcart;